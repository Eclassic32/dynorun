This is port of Chrome's Offline T-Rex game to Opera GX's gamestrip. might add new stuff idk 2 lzy
Link to store: (soon)

Source code of game itself: https://github.com/chrisdothtml/chrome-dino
